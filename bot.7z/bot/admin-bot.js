require('dotenv').config(); // Загружаем .env из текущей директории
const TelegramBot = require('node-telegram-bot-api');
const { SupabaseClient } = require('@supabase/supabase-js');

const botToken = process.env.TELEGRAM_ADMIN_BOT_TOKEN;
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const bot = new TelegramBot(botToken, { polling: true });
const supabase = new SupabaseClient(supabaseUrl, supabaseAnonKey);

// Команда /start
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 'Добро пожаловать! Используйте команду /list, чтобы увидеть список новых мастеров.');
});

// Команда /list — показывает список ожидаемых мастеров
bot.onText(/\/list/, async (msg) => {
  const chatId = msg.chat.id;

  const { data, error } = await supabase
    .from('master_verification')
    .select('*')
    .eq('status', 'ожидает');

  if (error || !data.length) {
    return bot.sendMessage(chatId, 'Нет новых мастеров на одобрение.');
  }

  for (const master of data) {
    const message = `
Имя: ${master.name}
Город: ${master.city}
Место приёма: ${master.location_type}
Услуги: ${master.services.join(', ')}
Стаж: ${master.experience}
Telegram: ${master.telegram_username}

Выберите действие:
`;

    const options = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Одобрить', callback_data: `approve:${master.telegram_username}` },
            { text: '❌ Отклонить', callback_data: `reject:${master.telegram_username}` }
          ]
        ]
      }
    };

    bot.sendMessage(chatId, message, options);
  }
});

// Обработка действий по нажатию на кнопки
bot.on('callback_query', async (query) => {
  const { id, data } = query;
  const chatId = query.message.chat.id;

  if (data.startsWith('approve:')) {
    const telegramUsername = data.split(':')[1];

    try {
      const response = await fetch(`https://your-vercel-url.vercel.app/api/masters/approve `, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ telegram_username: telegramUsername })
      });

      if (!response.ok) throw new Error('Ошибка одобрения мастера.');

      bot.answerCallbackQuery(id, 'Мастер одобрен!');
      bot.sendMessage(chatId, `✅ Мастер @${telegramUsername} успешно одобрен.`);
    } catch (err) {
      bot.answerCallbackQuery(id, 'Ошибка при одобрении.');
      console.error(err);
    }
  } else if (data.startsWith('reject:')) {
    const telegramUsername = data.split(':')[1];

    try {
      const response = await fetch(`https://your-vercel-url.vercel.app/api/masters/reject `, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ telegram_username: telegramUsername })
      });

      if (!response.ok) throw new Error('Ошибка отклонения мастера.');

      bot.answerCallbackQuery(id, 'Мастер отклонён!');
      bot.sendMessage(chatId, `❌ Мастер @${telegramUsername} отклонён.`);
    } catch (err) {
      bot.answerCallbackQuery(id, 'Ошибка при отклонении.');
      console.error(err);
    }
  }
});